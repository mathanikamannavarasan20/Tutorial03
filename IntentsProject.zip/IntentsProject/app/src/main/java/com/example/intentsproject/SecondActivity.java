package com.example.intentsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    EditText etNum1;
    EditText etNum2;
    TextView lbl;

    String number1;
    String number2;

    int n1,n2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        lbl = findViewById(R.id.lbl);

        Intent intent = getIntent();

        String number1 = intent.getStringExtra("n1");
        String number2 = intent.getStringExtra("n2");

        etNum1.setText(number1);
        etNum2.setText(number2);

        n1 = Integer.parseInt(number1);
        n2 = Integer.parseInt(number2);

    }

    public void add(View view){
        lbl.setText(number1 + "+" + number2 +"=" + (n1+n2));
    }
    public void sub(View view){
        lbl.setText(number1 + "-" + number2 +"=" + (n1-n2));
    }
    public void mul(View view){
        lbl.setText(number1 + "*" + number2 +"=" + (n1*n2));
    }
    public void divi(View view){
        lbl.setText(number1 + "/" + number2 +"=" + (n1/n2));
    }
}